-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.1.72-community - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table stellar.galaxy_ads
CREATE TABLE IF NOT EXISTS `galaxy_ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` int(11) NOT NULL,
  `expires` int(11) NOT NULL,
  `status` int(6) NOT NULL DEFAULT '0',
  `lang` varchar(6) COLLATE latin1_general_ci NOT NULL,
  `class` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `type` varchar(12) COLLATE latin1_general_ci NOT NULL,
  `notify` int(11) NOT NULL DEFAULT '0',
  `replies` varchar(12) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `author` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `title` varchar(35) COLLATE latin1_general_ci NOT NULL,
  `content` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumping data for table stellar.galaxy_ads: 5 rows
/*!40000 ALTER TABLE `galaxy_ads` DISABLE KEYS */;
INSERT INTO `galaxy_ads` (`id`, `time`, `expires`, `status`, `lang`, `class`, `type`, `notify`, `replies`, `author`, `title`, `content`) VALUES
	(1, 1182443697, 1182703211, 1, 'en', 'admin', 'humor', 0, '4', 'desmond', 'test ogÅ‚oszonka', 'blah blah blah'),
	(6, 1182622520, 0, 0, '', 'admin', '', 0, '0', 'desmond', '', 'test'),
	(5, 1182622251, 0, 0, '', 'admin', '', 0, '0', 'desmond', '', 'xdfsdfg'),
	(7, 1182622591, 0, 0, '', 'admin', 'reply', 0, '0', 'desmond', '', 'xfg'),
	(8, 1182622747, 0, 0, '', 'admin', 'reply', 0, '0', 'desmond', '1', 'dfhg qrde');
/*!40000 ALTER TABLE `galaxy_ads` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_attacks
CREATE TABLE IF NOT EXISTS `galaxy_attacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `owner` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `target` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `status` int(11) NOT NULL DEFAULT '0',
  `communicationlost` tinyint(1) NOT NULL DEFAULT '0',
  `efficacy` float NOT NULL DEFAULT '0',
  `begin` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `strategy` int(11) NOT NULL DEFAULT '0',
  `bonus` int(11) NOT NULL DEFAULT '0',
  `colonistskilled` int(11) NOT NULL DEFAULT '0',
  `scientistskilled` int(11) NOT NULL DEFAULT '0',
  `soldiers` int(11) NOT NULL DEFAULT '0',
  `soldierslost` int(11) NOT NULL DEFAULT '0',
  `soldierskilled` int(11) NOT NULL DEFAULT '0',
  `bx1killed` int(11) NOT NULL DEFAULT '0',
  `bx2killed` int(11) NOT NULL DEFAULT '0',
  `bx5killed` int(11) NOT NULL DEFAULT '0',
  `bx10` int(11) NOT NULL DEFAULT '0',
  `bx10lost` int(11) NOT NULL DEFAULT '0',
  `bx10killed` int(11) NOT NULL DEFAULT '0',
  `walker` int(11) NOT NULL DEFAULT '0',
  `walkerlost` int(11) NOT NULL DEFAULT '0',
  `walkerkilled` int(11) NOT NULL DEFAULT '0',
  `hawk` int(11) NOT NULL DEFAULT '0',
  `hawklost` int(11) NOT NULL DEFAULT '0',
  `hawkkilled` int(11) NOT NULL DEFAULT '0',
  `valkyrie` int(11) NOT NULL DEFAULT '0',
  `valkyrielost` int(11) NOT NULL DEFAULT '0',
  `valkyriekilled` int(11) NOT NULL DEFAULT '0',
  `crusader` int(11) NOT NULL DEFAULT '0',
  `crusaderlost` int(11) NOT NULL DEFAULT '0',
  `crusaderkilled` int(11) NOT NULL DEFAULT '0',
  `warrior` int(11) NOT NULL DEFAULT '0',
  `warriorlost` int(11) NOT NULL DEFAULT '0',
  `warriorkilled` int(11) NOT NULL DEFAULT '0',
  `dragon` int(11) NOT NULL DEFAULT '0',
  `dragonlost` int(11) NOT NULL DEFAULT '0',
  `dragonkilled` int(11) NOT NULL DEFAULT '0',
  `whisper` int(11) NOT NULL DEFAULT '0',
  `whisperlost` int(11) NOT NULL DEFAULT '0',
  `whisperkilled` int(11) NOT NULL DEFAULT '0',
  `nemesis` int(11) NOT NULL DEFAULT '0',
  `nemesislost` int(11) NOT NULL DEFAULT '0',
  `nemesiskilled` int(11) NOT NULL DEFAULT '0',
  `scavenger` int(11) NOT NULL DEFAULT '0',
  `scavengerlost` int(11) NOT NULL DEFAULT '0',
  `scavengerkilled` int(11) NOT NULL DEFAULT '0',
  `carrier` int(11) NOT NULL DEFAULT '0',
  `carrierlost` int(11) NOT NULL DEFAULT '0',
  `carrierkilled` int(11) NOT NULL DEFAULT '0',
  `vesselkilled` int(11) NOT NULL DEFAULT '0',
  `detectorkilled` int(11) NOT NULL DEFAULT '0',
  `satellitekilled` int(11) NOT NULL DEFAULT '0',
  `bee` int(11) NOT NULL DEFAULT '0',
  `beelost` int(11) NOT NULL DEFAULT '0',
  `beekilled` int(11) NOT NULL DEFAULT '0',
  `windgenerator` int(11) NOT NULL DEFAULT '0',
  `solarbattery` int(11) NOT NULL DEFAULT '0',
  `fusionreactor` int(11) NOT NULL DEFAULT '0',
  `bunker` int(11) NOT NULL DEFAULT '0',
  `score` int(11) NOT NULL DEFAULT '0',
  `metal` int(11) NOT NULL DEFAULT '0',
  `uran` int(11) NOT NULL DEFAULT '0',
  `crystals` int(11) NOT NULL DEFAULT '0',
  `credits` bigint(20) NOT NULL DEFAULT '0',
  `exp` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `login` (`login`),
  KEY `target` (`target`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_attacks: 0 rows
/*!40000 ALTER TABLE `galaxy_attacks` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_attacks` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_buildings
CREATE TABLE IF NOT EXISTS `galaxy_buildings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `begin` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `amount` int(11) NOT NULL DEFAULT '0',
  `score` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_buildings: 0 rows
/*!40000 ALTER TABLE `galaxy_buildings` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_buildings` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_chat
CREATE TABLE IF NOT EXISTS `galaxy_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` varchar(14) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `class` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `author` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `receiver` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `message` mediumtext COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_chat: 74 rows
/*!40000 ALTER TABLE `galaxy_chat` DISABLE KEYS */;
INSERT INTO `galaxy_chat` (`id`, `timestamp`, `type`, `class`, `author`, `receiver`, `message`) VALUES
	(38, '1187350615', '', 'admin', 'desmond', '', 'test'),
	(37, '1187350412', '', 'admin', 'desmond', '', 'test'),
	(36, '1187350383', '', 'admin', 'desmond', '', 'test'),
	(35, '1187350374', '', 'admin', 'desmond', '', 'test'),
	(34, '1187350355', '', 'admin', 'desmond', '', 'test'),
	(33, '1187350333', '', 'admin', 'desmond', '', '546'),
	(32, '1187350326', '', 'admin', 'desmond', '', 'test'),
	(31, '1187350248', '', 'admin', 'desmond', '', 'test'),
	(30, '1187350202', '', 'admin', 'desmond', '', 'test'),
	(29, '1187350181', 'clan', 'admin', 'desmond', '', 'hh'),
	(28, '1187350180', '', 'admin', 'desmond', '', 'j'),
	(27, '1187350176', '', 'admin', 'desmond', '', 'test'),
	(26, '1187350101', '', 'admin', 'desmond', '', 'test'),
	(25, '1187350098', '', 'admin', 'desmond', '', 'test'),
	(22, '1187350054', '', 'admin', 'desmond', '', 'test'),
	(23, '1187350093', '', 'admin', 'desmond', '', 'test'),
	(24, '1187350097', '', 'admin', 'desmond', '', 'test'),
	(21, '1187350052', '', 'admin', 'desmond', '', 'test'),
	(20, '1187350048', '', 'admin', 'desmond', '', 'test'),
	(19, '1187350003', '', 'admin', 'desmond', '', 'test'),
	(39, '1187350619', '', 'admin', 'desmond', '', 'tset\\\\'),
	(40, '1187350619', '', 'admin', 'desmond', '', 'tset\\\\'),
	(41, '1187350682', '', 'admin', 'desmond', '', 'test'),
	(42, '1187350722', '', 'admin', 'desmond', '', 'test'),
	(43, '1187350734', '', 'admin', 'desmond', '', 'test'),
	(44, '1187350761', '', 'admin', 'desmond', '', 'test'),
	(45, '1187350804', '', 'admin', 'desmond', '', 'test'),
	(46, '1187350822', '', 'admin', 'desmond', '', 'test'),
	(47, '1187351203', '', 'admin', 'desmond', '', '1'),
	(48, '1187351209', '', 'admin', 'desmond', '', '1'),
	(49, '1187351269', '', 'admin', 'desmond', '', '1'),
	(50, '1187351323', '', 'admin', 'desmond', '', '1'),
	(51, '1187351328', '', 'admin', 'desmond', '', '1'),
	(52, '1187351345', '', 'admin', 'desmond', '', '1'),
	(53, '1187351347', '', 'admin', 'desmond', '', '1'),
	(54, '1187351580', '', 'admin', 'desmond', '', '1'),
	(55, '1187351590', '', 'admin', 'desmond', '', '1'),
	(56, '1187351797', '', 'admin', 'desmond', '', '1'),
	(57, '1187351799', '', 'admin', 'desmond', '', '1'),
	(58, '1187351801', '', 'admin', 'desmond', '', '1'),
	(59, '1187351803', '', 'admin', 'desmond', '', '1'),
	(60, '1187351901', '', 'admin', 'desmond', '', '1'),
	(61, '1187351903', '', 'admin', 'desmond', '', '1'),
	(62, '1187351934', '', 'admin', 'desmond', '', ''),
	(63, '1187351936', '', 'admin', 'desmond', '', 'test'),
	(64, '1187351937', '', 'admin', 'desmond', '', 'test'),
	(65, '1187351943', '', 'admin', 'desmond', '', ''),
	(66, '1187351944', '', 'admin', 'desmond', '', ''),
	(67, '1187351945', '', 'admin', 'desmond', '', ''),
	(68, '1187351950', '', 'admin', 'desmond', '', ''),
	(69, '1187351965', '', 'admin', 'desmond', '', ''),
	(70, '1187351980', '', 'admin', 'desmond', '', ''),
	(71, '1187351996', '', 'admin', 'desmond', '', ''),
	(72, '1187352000', '', 'admin', 'desmond', '', ''),
	(73, '1187352009', '', 'admin', 'desmond', '', ''),
	(74, '1187352019', '', 'admin', 'desmond', '', ''),
	(75, '1187352026', '', 'admin', 'desmond', '', ''),
	(76, '1187352035', '', 'admin', 'desmond', '', ''),
	(77, '1187352047', '', 'admin', 'desmond', '', ''),
	(78, '1187352060', '', 'admin', 'desmond', '', ''),
	(79, '1187352076', '', 'admin', 'desmond', '', ''),
	(80, '1187352092', '', 'admin', 'desmond', '', ''),
	(81, '1187352107', '', 'admin', 'desmond', '', ''),
	(82, '1187352122', '', 'admin', 'desmond', '', ''),
	(83, '1187352152', '', 'admin', 'desmond', '', 'kurwa'),
	(84, '1187352457', 'clan', 'admin', 'desmond', 'Kademlia', 'test'),
	(85, '1187352479', 'clan', 'admin', 'desmond', 'Kademlia', 'test kanaÅ‚u'),
	(86, '1187352486', 'clan', 'admin', 'desmond', 'Kademlia', 'umcyk'),
	(87, '1187352777', 'clan', 'admin', 'desmond', 'Kademlia', 'test'),
	(88, '1187352778', 'clan', 'admin', 'desmond', 'Kademlia', 'tset'),
	(89, '1187354214', 'clan', 'admin', 'desmond', 'Kademlia', 'kurde'),
	(90, '1187354260', 'clan', 'admin', 'desmond', 'Kademlia', 'umcyk'),
	(91, '1231254004', 'clan', 'admin', 'desmond', 'Kademlia', 'gfdg'),
	(92, '1653743619', '', 'admin', 'desmond', '', '');
/*!40000 ALTER TABLE `galaxy_chat` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_clanmessages
CREATE TABLE IF NOT EXISTS `galaxy_clanmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('','attack','reject','donate','admit','join','recultivation','leave','councildismiss','ownerchange','counciladmit','namechange','statuschange','pactproposal','pactaccepted','pactrejected','declaredwar') COLLATE latin1_general_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `time` int(11) NOT NULL DEFAULT '0',
  `clan` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `from` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `to` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `subject` varchar(120) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `credits` int(11) NOT NULL DEFAULT '0',
  `crystals` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `clan` (`clan`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_clanmessages: 18 rows
/*!40000 ALTER TABLE `galaxy_clanmessages` DISABLE KEYS */;
INSERT INTO `galaxy_clanmessages` (`id`, `type`, `timestamp`, `time`, `clan`, `from`, `to`, `subject`, `credits`, `crystals`) VALUES
	(1, 'declaredwar', '2007-07-20 17:43:24', 309524, 'Dupczyki', 'Dharma', '', '', 0, 0),
	(2, 'declaredwar', '2007-07-20 17:43:24', 309524, 'Dharma', 'Dupczyki', '1', '', 0, 0),
	(3, 'declaredwar', '2007-07-20 17:43:24', 309524, 'Dharma', 'Fraglesy', '', '', 0, 0),
	(4, 'declaredwar', '2007-07-20 17:43:24', 309524, 'Fraglesy', 'Dharma', '1', '', 0, 0),
	(5, 'pactproposal', '2007-07-20 18:16:38', 309531, 'Dharma', 'Pierdoly', '', 'peace', 0, 0),
	(6, 'pactproposal', '2007-07-20 18:16:38', 309531, 'Pierdoly', 'Dharma', '1', 'peace', 0, 0),
	(7, 'pactproposal', '2007-07-20 18:21:53', 309532, 'Dharma', 'Dupczyki', '', 'nap', 0, 0),
	(8, 'pactproposal', '2007-07-20 18:21:53', 309532, 'Dupczyki', 'Dharma', '1', 'nap', 0, 0),
	(9, 'statuschange', '2007-08-17 17:07:47', 317581, 'kademlia', 'desmond', '', '', 0, 0),
	(10, 'statuschange', '2007-08-17 17:12:01', 317582, 'kademlia', 'desmond', '', '', 0, 0),
	(11, 'statuschange', '2007-08-17 17:15:20', 317583, 'kademlia', 'desmond', '', '', 0, 0),
	(12, 'statuschange', '2007-08-17 17:16:42', 317583, 'kademlia', 'desmond', '', '', 0, 0),
	(13, 'statuschange', '2007-08-17 17:17:25', 317583, 'kademlia', 'desmond', '', '', 0, 0),
	(14, 'statuschange', '2007-08-17 17:18:06', 317583, 'kademlia', 'desmond', '', '', 0, 0),
	(15, 'statuschange', '2007-08-17 17:18:25', 317583, 'kademlia', 'desmond', '', '', 0, 0),
	(16, 'statuschange', '2007-08-17 17:21:01', 317584, 'kademlia', 'desmond', '', '', 0, 0),
	(17, 'statuschange', '2007-08-17 17:35:26', 317587, 'kademlia', 'desmond', '', '', 0, 0),
	(18, 'statuschange', '2007-08-17 17:52:00', 317590, 'kademlia', 'desmond', '', '', 0, 0);
/*!40000 ALTER TABLE `galaxy_clanmessages` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_colonies
CREATE TABLE IF NOT EXISTS `galaxy_colonies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `owner` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `planet` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `avatar` varchar(128) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `credits` bigint(20) NOT NULL DEFAULT '0',
  `thicks` int(11) NOT NULL DEFAULT '0',
  `attacked` int(11) NOT NULL DEFAULT '0',
  `damage` float NOT NULL DEFAULT '0',
  `infrastructure` int(11) NOT NULL DEFAULT '50',
  `science` int(11) NOT NULL DEFAULT '25',
  `military` int(11) NOT NULL DEFAULT '25',
  `satisfaction` float NOT NULL DEFAULT '0',
  `lost` int(11) NOT NULL DEFAULT '0',
  `sources` text COLLATE latin1_general_ci NOT NULL,
  `resources` text COLLATE latin1_general_ci NOT NULL,
  `units` text COLLATE latin1_general_ci NOT NULL,
  `structures` text COLLATE latin1_general_ci NOT NULL,
  `technologies` text COLLATE latin1_general_ci NOT NULL,
  `disabled` tinytext COLLATE latin1_general_ci NOT NULL,
  `affects` tinytext COLLATE latin1_general_ci NOT NULL,
  `events` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `owner` (`owner`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_colonies: 4 rows
/*!40000 ALTER TABLE `galaxy_colonies` DISABLE KEYS */;
INSERT INTO `galaxy_colonies` (`id`, `name`, `owner`, `planet`, `avatar`, `credits`, `thicks`, `attacked`, `damage`, `infrastructure`, `science`, `military`, `satisfaction`, `lost`, `sources`, `resources`, `units`, `structures`, `technologies`, `disabled`, `affects`, `events`) VALUES
	(1, 'Novistrana', 'desmond', 'ben', 'http://localhost/galaxy_project/sq/gallery/space/icons/ben.jpg', 0, 1872184, 0, 0, 50, 25, 25, 0, 0, 'metal,uran,1379.5,704.5', 'energy,metal,silicon,uran,plutonium,deuterium,organics,food,crystals,1984325,986855,499980,99980,49930,9980,4980,99980,480', 'colonists,scientists,soldiers,hawk,nemesis,spacevan,speeditor,100,100,100,151,5,20,20', 'base,laboratory,factory,spacedepot,flats,barracks,academy,bunker,lasertower,plasmatower,windgenerator,solarbattery,fusionreactor,metalextractor,uranmine,foodplanting,energysilo,metalsilo,uransilo,plutoniumsilo,foodsilo,5,5,20,5,1000,1000,25,200,50,25,1500,1000,50,100,250,1200,2500,2000,1500,1000,1000', '', '', '', 'sourcesexpend,1872139'),
	(6, 'Mouse', 'lord_nacro', 'ben', '', 0, 320710, 0, 0, 50, 25, 25, 0, 0, '', 'metal,silicon,uran,plutonium,deuterium,organics,food,crystals,10120,20,20020,70,20,20,45,20', 'spacevan,speeditor,50,50', 'base,foodplanting,2,1', '', '', '', ''),
	(10, 'Factoria', 'pafawag', 'ben', '', 0, 314983, 0, 0, 50, 25, 25, 0, 0, '', '', 'colonists,scientists,soldiers,ax3,ax6,worker,100,100,100,100,100,5', 'tron,1', '', '', '', ''),
	(9, 'Trias', 'UNK', 'ben', '', 0, 319616, 0, 0, 50, 25, 25, 0, 0, '', 'crystals,99600000', 'worker,5', 'tron,1', '', '', '', '');
/*!40000 ALTER TABLE `galaxy_colonies` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_config
CREATE TABLE IF NOT EXISTS `galaxy_config` (
  `config_key` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `config_value` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`config_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumping data for table stellar.galaxy_config: 3 rows
/*!40000 ALTER TABLE `galaxy_config` DISABLE KEYS */;
INSERT INTO `galaxy_config` (`config_key`, `config_value`) VALUES
	('Version', '0.5.0'),
	('Ranks', 'admin,<b>Admin</b>,<b>Admin</b>,color:#ff3300;font-weight:bold;,background-color: #3F172C;|clan_member,Player,Zrzeszony,color:#ffff99;,|global_mod,<b>Moderator Globalny</b>,<b>Global Moderator</b>,color:#ffc020;font-weight:bold;,background-color: #2C3F17;|mod,<b>Moderator</b>,<b>Moderator</b>,color:#aaccff;,background-color: #14263A;|bot,Bot,Bot,color:yellow;;font-weight:bold;'),
	('Status', '0');
/*!40000 ALTER TABLE `galaxy_config` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_descriptions
CREATE TABLE IF NOT EXISTS `galaxy_descriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `locale` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumping data for table stellar.galaxy_descriptions: 0 rows
/*!40000 ALTER TABLE `galaxy_descriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_descriptions` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_dev
CREATE TABLE IF NOT EXISTS `galaxy_dev` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(12) COLLATE utf8_polish_ci NOT NULL,
  `category` varchar(12) COLLATE utf8_polish_ci NOT NULL,
  `date` int(11) NOT NULL,
  `priority` varchar(12) COLLATE utf8_polish_ci NOT NULL DEFAULT '1',
  `status` varchar(12) COLLATE utf8_polish_ci NOT NULL DEFAULT '1',
  `content` text COLLATE utf8_polish_ci NOT NULL,
  `files` text COLLATE utf8_polish_ci NOT NULL,
  `author` varchar(16) COLLATE utf8_polish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci COMMENT='development tool';

-- Dumping data for table stellar.galaxy_dev: 4 rows
/*!40000 ALTER TABLE `galaxy_dev` DISABLE KEYS */;
INSERT INTO `galaxy_dev` (`id`, `type`, `category`, `date`, `priority`, `status`, `content`, `files`, `author`) VALUES
	(1, '', 'feature', 323232, '2', '3', '$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']$d[\'content\']', '', ''),
	(4, '', 'attack', 1187283132, '3', '3', 'test', '', 'desmond'),
	(6, '', 'engine', 1187287256, '1', '2', 'ftest', 'saf\r<br />saf\r<br />sad\r<br />', 'desmond'),
	(7, '', 'engine', 1187297242, '1', '2', 'Fragles\r\nFragles\r\nFragles\r\nFragles\r\nFragles\r\nFragles\r\nFragles\r\n', 'Fragles\r<br />Fragles\r<br />FraglesFragles\r<br />Fragles\r<br />Fragles\r<br />Fragles', 'desmond');
/*!40000 ALTER TABLE `galaxy_dev` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_diplomacy
CREATE TABLE IF NOT EXISTS `galaxy_diplomacy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('peace','nap','alliance','war') NOT NULL,
  `newtype` varchar(16) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `secret` int(3) NOT NULL,
  `stardate` int(11) NOT NULL,
  `expires` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `clan1` varchar(32) NOT NULL,
  `clan2` varchar(32) NOT NULL,
  `side` varchar(32) NOT NULL,
  `guarantor` varchar(24) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Dumping data for table stellar.galaxy_diplomacy: 0 rows
/*!40000 ALTER TABLE `galaxy_diplomacy` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_diplomacy` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_equipment
CREATE TABLE IF NOT EXISTS `galaxy_equipment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `name` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` varchar(16) COLLATE latin1_general_ci DEFAULT NULL,
  `class` enum('','gold','silver','bronze') COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `localization` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `ship` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `count` int(11) NOT NULL DEFAULT '0',
  `damaged` tinyint(4) NOT NULL DEFAULT '0',
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `price` int(11) NOT NULL DEFAULT '0',
  `parameters` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `use` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=86 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_equipment: 6 rows
/*!40000 ALTER TABLE `galaxy_equipment` DISABLE KEYS */;
INSERT INTO `galaxy_equipment` (`id`, `owner`, `name`, `type`, `class`, `localization`, `ship`, `count`, `damaged`, `active`, `price`, `parameters`, `use`) VALUES
	(84, 'desmond', 'ionengine', 'engine', '', '', '1', 0, 0, 1, 1000000, '', 0),
	(85, 'desmond', 'titaniumplates', 'armour', '', '', '1', 0, 0, 1, 78000, '', 0),
	(80, 'desmond', 'lasercannon', 'weaponry', '', '', '1', 0, 0, 1, 10000, '', 0),
	(81, 'desmond', 'lasercannon', 'weaponry', '', '', '1', 0, 0, 1, 10000, '', 0),
	(82, 'desmond', 'lasercannon', 'weaponry', '', '', '1', 0, 0, 1, 10000, '', 0),
	(83, 'desmond', 'titaniumplates', 'armour', '', '', '', 0, 0, 0, 78000, '', 0);
/*!40000 ALTER TABLE `galaxy_equipment` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_events
CREATE TABLE IF NOT EXISTS `galaxy_events` (
  `event_timestamp` varchar(14) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `event_from` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `event_subject` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `event_message` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  KEY `event_timestamp` (`event_timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumping data for table stellar.galaxy_events: 0 rows
/*!40000 ALTER TABLE `galaxy_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_events` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_exchange
CREATE TABLE IF NOT EXISTS `galaxy_exchange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stardate` int(32) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `owner` varchar(32) NOT NULL,
  `exchange` varchar(32) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `load` varchar(32) NOT NULL,
  `amount` int(11) NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table stellar.galaxy_exchange: 5 rows
/*!40000 ALTER TABLE `galaxy_exchange` DISABLE KEYS */;
INSERT INTO `galaxy_exchange` (`id`, `stardate`, `timestamp`, `owner`, `exchange`, `ip`, `load`, `amount`, `price`) VALUES
	(1, 302747, '2007-06-27 01:56:41', 'desmond', '', '', 'energy', 582, 40),
	(2, 302747, '2007-06-27 01:06:42', 'desmond', 'mulahay', '127.0.0.1', 'energy', 100, 40),
	(3, 302747, '2007-06-27 01:06:42', 'desmond', 'mulahay', '127.0.0.1', 'energy', 500, 40),
	(4, 302747, '2007-06-27 01:06:42', 'desmond', 'mulahay', '127.0.0.1', 'energy', 1000, 40),
	(5, 302882, '2007-06-27 12:32:07', 'desmond', 'mulahay', '127.0.0.1', 'uran', 5, 50);
/*!40000 ALTER TABLE `galaxy_exchange` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_exploration
CREATE TABLE IF NOT EXISTS `galaxy_exploration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `type` enum('planet','galaxy') COLLATE latin1_general_ci NOT NULL DEFAULT 'planet',
  `target` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `begin` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `colonists` int(11) NOT NULL DEFAULT '0',
  `scientists` int(11) NOT NULL DEFAULT '0',
  `soldiers` int(11) NOT NULL DEFAULT '0',
  `vessels` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_exploration: 0 rows
/*!40000 ALTER TABLE `galaxy_exploration` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_exploration` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_forces
CREATE TABLE IF NOT EXISTS `galaxy_forces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `target` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `type` enum('attack','spy','missile','transport') COLLATE latin1_general_ci NOT NULL,
  `status` int(11) NOT NULL,
  `strategy` int(11) NOT NULL,
  `begin` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `distance` int(11) NOT NULL,
  `units` text COLLATE latin1_general_ci NOT NULL,
  `killed` text COLLATE latin1_general_ci NOT NULL,
  `lost` text COLLATE latin1_general_ci NOT NULL,
  `destroyed` text COLLATE latin1_general_ci NOT NULL,
  `loot` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='Galaxy Forces xD';

-- Dumping data for table stellar.galaxy_forces: 0 rows
/*!40000 ALTER TABLE `galaxy_forces` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_forces` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_groups
CREATE TABLE IF NOT EXISTS `galaxy_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `created` date NOT NULL DEFAULT '0000-00-00',
  `description` varchar(80) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `ranks` text COLLATE latin1_general_ci NOT NULL,
  `clanmsg` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `reqinfo` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `avatar` varchar(43) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `owner` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `co1` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `co2` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `credits` int(11) NOT NULL DEFAULT '0',
  `score` int(11) NOT NULL DEFAULT '0',
  `level` float NOT NULL DEFAULT '1',
  `tax` int(11) NOT NULL DEFAULT '15',
  `attack` int(11) NOT NULL DEFAULT '500',
  `defense` int(11) NOT NULL DEFAULT '500',
  `www` varchar(54) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_groups: 1 rows
/*!40000 ALTER TABLE `galaxy_groups` DISABLE KEYS */;
INSERT INTO `galaxy_groups` (`id`, `name`, `created`, `description`, `ranks`, `clanmsg`, `reqinfo`, `avatar`, `owner`, `co1`, `co2`, `credits`, `score`, `level`, `tax`, `attack`, `defense`, `www`) VALUES
	(1, 'kademlia', '0000-00-00', '', 'Archiwista,Szeregowy,council,0000010,0000000,1111100', '[justify][b]Lorem ipsum[/b] dolor sit amet, consectetuer adipiscing elit. Pellentesque erat ligula, feugiat et, lacinia convallis, tristique non, justo. Nam vestibulum pede at libero. Curabitur cursus congue quam. Vestibulum vitae sem. Maecenas feugiat, or', 'Aenean dignissim. Suspendisse potenti. Duis arcu. Nulla quam. Proin augue. Vivamus sem. Nunc orci. Aliquam erat volutpat. Nunc in sapien. Mauris nunc sapien, ullamcorper eu, consequat sit amet, vulputate in, sem. Sed tincidunt est sit amet ante. Donec id e', '', 'desmond', '', '', 0, 0, 1, 15, 500, 500, '');
/*!40000 ALTER TABLE `galaxy_groups` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_items
CREATE TABLE IF NOT EXISTS `galaxy_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` varchar(16) COLLATE latin1_general_ci DEFAULT NULL,
  `kind` enum('','upgrade') COLLATE latin1_general_ci NOT NULL,
  `class` enum('','gold','silver','bronze') COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `count` int(11) NOT NULL DEFAULT '0',
  `price` int(11) NOT NULL DEFAULT '0',
  `distance` int(11) NOT NULL DEFAULT '0',
  `req_level` int(11) NOT NULL DEFAULT '0',
  `req_strength` int(11) NOT NULL DEFAULT '0',
  `req_agility` int(11) NOT NULL DEFAULT '0',
  `req_psi` int(11) NOT NULL DEFAULT '0',
  `req_force` int(11) NOT NULL DEFAULT '0',
  `req_mp` int(11) NOT NULL DEFAULT '0',
  `req_hp` int(11) NOT NULL DEFAULT '0',
  `req_intellect` int(11) NOT NULL DEFAULT '0',
  `req_knowledge` int(11) NOT NULL DEFAULT '0',
  `req_pocketstealing` int(11) NOT NULL DEFAULT '0',
  `req_hacking` int(11) NOT NULL DEFAULT '0',
  `req_alcoholism` int(11) NOT NULL DEFAULT '0',
  `weight` float NOT NULL DEFAULT '0',
  `slots` int(12) NOT NULL DEFAULT '1',
  `min` float NOT NULL DEFAULT '0',
  `max` float NOT NULL DEFAULT '0',
  `armor` float NOT NULL DEFAULT '0',
  `hit` int(11) NOT NULL DEFAULT '0',
  `criticalhit` int(11) NOT NULL DEFAULT '0',
  `critical` float NOT NULL DEFAULT '0',
  `block` int(11) NOT NULL DEFAULT '0',
  `speed` int(11) NOT NULL DEFAULT '0',
  `deaf` int(11) NOT NULL DEFAULT '0',
  `hide` int(11) NOT NULL DEFAULT '0',
  `protection` int(11) NOT NULL DEFAULT '0',
  `hp` int(11) NOT NULL DEFAULT '0',
  `mp` int(11) NOT NULL DEFAULT '0',
  `parameters` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `use` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  FULLTEXT KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_items: 91 rows
/*!40000 ALTER TABLE `galaxy_items` DISABLE KEYS */;
INSERT INTO `galaxy_items` (`id`, `name`, `type`, `kind`, `class`, `count`, `price`, `distance`, `req_level`, `req_strength`, `req_agility`, `req_psi`, `req_force`, `req_mp`, `req_hp`, `req_intellect`, `req_knowledge`, `req_pocketstealing`, `req_hacking`, `req_alcoholism`, `weight`, `slots`, `min`, `max`, `armor`, `hit`, `criticalhit`, `critical`, `block`, `speed`, `deaf`, `hide`, `protection`, `hp`, `mp`, `parameters`, `use`) VALUES
	(1, 'knife', 'weapon2', '', '', 0, 2500, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.1, 0, 0, 3, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(2, 'lance', 'weapon2', '', '', 0, 15000, 0, 3, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.2, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(3, 'paralyzer', 'weapon2', '', '', 0, 10000, 0, 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.05, 0, 0.15, 0.25, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, '', 0),
	(4, 'brush', 'weapon', '', '', 0, 25000, 0, 3, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.3, 0, 2, 7, 0.15, 1, 1, 2, 5, 0, -5, 0, 0, 0, 0, '', 0),
	(5, 'lightarmor', 'armor', '', '', 0, 35000, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(6, 'suonn', 'weapon', '', 'silver', 0, 200000, 0, 7, 0, 5, 0, 0, 0, 0, 0, 5, 0, 0, 0, 7, 0, 5, 14, 0.25, 2, 0, 3, 0, 0, -10, 0, 0, 0, 0, '', 0),
	(32, 'laserpistol', 'weapon2', '', '', 0, 6000, 1, 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.8, 0, 1, 4, 0, -5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(10, 'powerbelt', 'belt', '', '', 0, 12000, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.4, 0, 0, 0, 0.25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(11, 'belt', 'belt', '', '', 0, 2500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.2, 0, 0, 0, 0.15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(12, 'lightninggun', 'weapon2', '', '', 0, 10000, 1, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 18, 0, 2, 3, 0, 3, 0, 2, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(14, 'energyarmor', 'armor', '', '', 0, 50000, 0, 15, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0, 0, 1, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, '', 0),
	(15, 'crystalarmor', 'armor', '', 'bronze', 0, 100000, 0, 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(16, 'rifle', 'weapon', '', '', 0, 25000, 1, 5, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 3, 6, 0, 2, 0, 1.5, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(17, 'laserrifle', 'weapon', '', '', 0, 35000, 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 17, 0, 4, 8, 0, 5, 0, 1.5, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(18, 'pins', 'weapon2', '', '', 0, 10000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.7, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(19, 'mshirt', 'armor', '', '', 0, 25000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0.25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(20, 'powerarmor', 'armor', '', '', 0, 40000, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11, 0, 0, 0, 0.5, -2, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(21, 'sword', 'weapon', '', '', 0, 35000, 0, 0, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 0, 2, 6, 0, 0, 0, 2.5, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(22, 'amoebasword', 'weapon', '', '', 0, 50000, 0, 0, 4, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 0, 3, 7, 0, 0, 0, 2.5, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(23, 'medpack', 'item', '', '', 1, 3000, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 2, '', 10),
	(24, 'xtd', 'weapon', '', '', 0, 50000, 1, 14, 5, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 30, 0, 3, 13, 0, 15, 3, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(25, 'xtd-2', 'weapon', '', '', 0, 75000, 1, 21, 5, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 32, 0, 2, 15, 0, 15, 3, 0, 5, 0, 0, 0, 5, 0, 0, '', 0),
	(26, 'xtd-m', 'weapon', '', '', 0, 100000, 1, 29, 10, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 27, 0, 1.5, 17, 1, 15, 0, 3, 10, 0, 0, 0, 10, 0, 0, '', 0),
	(27, 'lasergun', 'weapon', '', '', 0, 22000, 1, 15, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 2, 5, 0, 2, 0, 1, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(28, 'plasmagun', 'weapon', '', '', 0, 88000, 1, 18, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 3.5, 8.5, 0.25, 20, 0, 2, 2, 0, 0, 0, 0, 0, 0, '', 0),
	(29, 'energyweapon', 'weapon', '', '', 0, 110000, 1, 15, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 3, 8, 0.5, 0, 5, 1, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(30, 'blaster', 'weapon', '', '', 0, 40000, 1, 22, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 2, 7, 0, -25, -10, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(31, 'wavedesintegrator', 'weapon', '', 'silver', 0, 250000, 1, 25, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 0, 10, 10, -2, -10, 0, 5, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(33, 'yellowgem', 'gem', '', '', 1, 2500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(34, 'orangegem', 'gem', '', '', 1, 5000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(35, 'greengem', 'gem', '', '', 1, 10000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(36, 'redgem', 'gem', '', '', 1, 20000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(37, 'whitegem', 'gem', '', '', 1, 40000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(38, 'bluegem', 'gem', '', 'bronze', 1, 100000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(39, 'violetgem', 'gem', '', 'silver', 1, 200000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(40, 'blackgem', 'gem', '', 'gold', 1, 500000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(41, 'energybomb', 'item', '', '', 1, 25000, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, '', 40),
	(42, 'a3', 'artifact', '', 'gold', 0, 1000000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(43, 'a3sword', 'weapon', '', 'bronze', 0, 145000, 0, 20, 10, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 15, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(44, 'magneticblade', 'weapon', '', '', 0, 25000, 0, 7, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 4, 0.1, 0, 15, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(45, 'pills', 'item', '', '', 1, 40000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 3, '', 25),
	(46, 'bolt', 'weapon', '', '', 0, 23000, 0, 10, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 5, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(47, 'acidclaws', 'weapon2', '', '', 0, 43000, 1, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1.5, 2.5, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(48, 'helmet', 'helmet', '', '', 0, 3000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(49, 'hood', 'helmet', '', '', 0, 21000, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1.15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(50, 'crystalhelmet', 'helmet', '', 'bronze', 0, 112000, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1.25, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(51, 'warhelmet', 'helmet', '', '', 0, 13000, 0, 12, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(52, 'powerhelmet', 'helmet', '', '', 0, 23000, 0, 17, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(53, 'stamina', 'item', '', '', 1, 700, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 20),
	(54, 'drugs', 'item', '', '', 1, 1200, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 15),
	(55, 'diamondearrings', 'useless', '', '', 0, 12000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(56, 'amiearrings', 'useless', '', 'silver', 0, 75000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(57, 'datapad', 'special', '', '', 0, 18000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(58, 'controlpad', 'special', '', '', 0, 24000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(59, 'warplasma', 'weapon', '', '', 0, 90000, 1, 17, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(60, 'stungun', 'weapon2', '', '', 0, 70000, 0, 25, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.5, 4.5, 0, 0, 0, 0, 0, 0, 25, 0, 0, 0, 0, '', 0),
	(61, 'spice', 'item', '', '', 1, 14500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, '', 25),
	(62, 'creditcard', 'creditcard', '', '', 0, 11000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '100000', 0),
	(63, 'vipcard', 'creditcard', '', 'bronze', 0, 55000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '250000', 0),
	(64, 'silvercard', 'creditcard', '', 'silver', 0, 111000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '1000000', 0),
	(65, 'goldcard', 'creditcard', '', 'gold', 0, 555000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '15000000', 0),
	(66, 'spade', 'spade', '', '', 0, 1500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '15', 0),
	(67, 'electricspade', 'spade', '', 'bronze', 0, 15000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '25', 0),
	(68, 'ultraspade', 'spade', '', 'silver', 0, 150000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '40', 0),
	(69, 'goldenspade', 'spade', '', 'gold', 0, 150000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '50', 0),
	(70, 'beer', 'drink', '', '', 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '5', 0),
	(71, 'darkbeer', 'drink', '', '', 1, 80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7', 0),
	(72, 'lightbeer', 'drink', '', '', 1, 70, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3', 0),
	(73, 'gin', 'drink', '', '', 1, 350, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '37', 0),
	(74, 'whisky', 'drink', '', '', 1, 800, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '50', 0),
	(75, 'vodka', 'drink', '', '', 1, 250, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '40', 0),
	(76, 'redwine', 'drink', '', '', 1, 270, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '10', 0),
	(77, 'whitewine', 'drink', '', '', 1, 230, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9', 0),
	(78, 'grandredwine', 'drink', '', 'bronze', 1, 2500, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '10', 0),
	(79, 'grandwhitewine', 'drink', '', 'bronze', 1, 2300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '9', 0),
	(80, 'cheapwine', 'drink', '', '', 1, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '7', 0),
	(81, 'malibu', 'drink', '', '', 1, 750, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '16', 0),
	(82, 'scanner', 'scanner', '', '', 0, 100000, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '1', 0),
	(83, 'spyscanner', 'scanner', '', '', 0, 500000, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2', 0),
	(84, 'microscanner', 'scanner', '', '', 0, 100000, 0, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3', 0),
	(85, 'ultrascanner', 'scanner', '', '', 0, 500000, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4', 0),
	(86, 'lighthelmet', 'helmet', '', '', 0, 41000, 0, 15, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(87, 'scanner', 'scanner', '', '', 0, 100000, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '1', 0),
	(88, 'spyscanner', 'scanner', '', '', 0, 500000, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2', 0),
	(89, 'microscanner', 'scanner', '', '', 0, 100000, 0, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '3', 0),
	(90, 'ultrascanner', 'scanner', '', '', 0, 500000, 0, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '4', 0),
	(91, 'llasercannon', 'weaponry', 'upgrade', '', 0, 2500, 0, 0, 20, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 5, 1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(92, 'lasercannon', 'weaponry', 'upgrade', '', 0, 10000, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 10, 1, 0, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0),
	(93, 'xengine', 'engine', 'upgrade', '', 0, 40000, 0, 0, 0, 0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 10, 1, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, '', 0),
	(94, 'ionengine', 'engine', 'upgrade', '', 0, 1000000, 0, 0, 0, 0, 0, 15, 0, 0, 0, 0, 0, 0, 0, 25, 2, 0, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, 0, 0, '', 0),
	(95, 'titaniumplates', 'armour', 'upgrade', '', 0, 78000, 0, 0, 5000, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 30, 1, 0, 0, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0);
/*!40000 ALTER TABLE `galaxy_items` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_markets
CREATE TABLE IF NOT EXISTS `galaxy_markets` (
  `position` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `level` int(11) NOT NULL DEFAULT '0',
  `reputation` int(11) NOT NULL DEFAULT '0',
  `energybuyaverage` float NOT NULL DEFAULT '0',
  `energybuy` float NOT NULL DEFAULT '0',
  `energysellaverage` float NOT NULL DEFAULT '0',
  `energysell` float NOT NULL DEFAULT '0',
  `siliconbuyaverage` float NOT NULL DEFAULT '0',
  `siliconbuy` float NOT NULL DEFAULT '0',
  `siliconsellaverage` float NOT NULL DEFAULT '0',
  `siliconsell` float NOT NULL DEFAULT '0',
  `metalbuyaverage` float NOT NULL DEFAULT '0',
  `metalbuy` float NOT NULL DEFAULT '0',
  `metalsellaverage` float NOT NULL DEFAULT '0',
  `metalsell` float NOT NULL DEFAULT '0',
  `uranbuyaverage` float NOT NULL DEFAULT '0',
  `uranbuy` float NOT NULL DEFAULT '0',
  `uransellaverage` float NOT NULL DEFAULT '0',
  `uransell` float NOT NULL DEFAULT '0',
  `plutoniumbuyaverage` float NOT NULL DEFAULT '0',
  `plutoniumbuy` float NOT NULL DEFAULT '0',
  `plutoniumsellaverage` float NOT NULL DEFAULT '0',
  `plutoniumsell` float NOT NULL DEFAULT '0',
  `deuteriumbuyaverage` float NOT NULL DEFAULT '0',
  `deuteriumbuy` float NOT NULL DEFAULT '0',
  `deuteriumsellaverage` float NOT NULL DEFAULT '0',
  `deuteriumsell` float NOT NULL DEFAULT '0',
  `foodbuyaverage` float NOT NULL DEFAULT '0',
  `foodbuy` float NOT NULL DEFAULT '0',
  `foodsellaverage` float NOT NULL DEFAULT '0',
  `foodsell` float NOT NULL DEFAULT '0',
  `crystalsbuyaverage` float NOT NULL DEFAULT '0',
  `crystalsbuy` float NOT NULL DEFAULT '0',
  `crystalssellaverage` float NOT NULL DEFAULT '0',
  `crystalssell` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`position`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_markets: 11 rows
/*!40000 ALTER TABLE `galaxy_markets` DISABLE KEYS */;
INSERT INTO `galaxy_markets` (`position`, `level`, `reputation`, `energybuyaverage`, `energybuy`, `energysellaverage`, `energysell`, `siliconbuyaverage`, `siliconbuy`, `siliconsellaverage`, `siliconsell`, `metalbuyaverage`, `metalbuy`, `metalsellaverage`, `metalsell`, `uranbuyaverage`, `uranbuy`, `uransellaverage`, `uransell`, `plutoniumbuyaverage`, `plutoniumbuy`, `plutoniumsellaverage`, `plutoniumsell`, `deuteriumbuyaverage`, `deuteriumbuy`, `deuteriumsellaverage`, `deuteriumsell`, `foodbuyaverage`, `foodbuy`, `foodsellaverage`, `foodsell`, `crystalsbuyaverage`, `crystalsbuy`, `crystalssellaverage`, `crystalssell`) VALUES
	('darkstar', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 0, 0, 0, 250, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 0, 3, 0, 0, 0, 1250, 0),
	('ring', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 22, 0, 0, 0, 0, 0, 22.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 43, 0, 7.2, 0, 0, 0, 0, 0),
	('angus', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 3.2, 0, 130, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 37, 0, 0, 0, 15000, 0, 600, 0),
	('ben', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3.1, 0, 150, 0, 12.5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4.5, 0, 0, 0, 0, 0),
	('amoeba', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 12, 0, 0, 0, 170, 0, 60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 40, 0, 1.2, 0, 0, 0, 0, 0),
	('harmony', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10000, 0, 1500, 0),
	('phantomia', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 0, 12.8, 0, 130, 0, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 60, 0, 25, 0, 0, 0, 0, 0),
	('prophetie', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2.1, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3.2, 0, 0, 0, 20, 0),
	('phantasmagoria', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 220, 0, 45, 0, 400, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
	('nemesis', 5, 0, 0, 3, 0, 0, 0, 0, 7, 0, 63, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0),
	('coruscant', 10, 0, 330, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
/*!40000 ALTER TABLE `galaxy_markets` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_messages
CREATE TABLE IF NOT EXISTS `galaxy_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('message','report') COLLATE latin1_general_ci NOT NULL DEFAULT 'message',
  `from` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `to` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `subject` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `message` text COLLATE latin1_general_ci NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `timestamp` varchar(14) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `to` (`to`),
  KEY `read` (`read`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_messages: 1 rows
/*!40000 ALTER TABLE `galaxy_messages` DISABLE KEYS */;
INSERT INTO `galaxy_messages` (`id`, `type`, `from`, `to`, `subject`, `message`, `read`, `timestamp`) VALUES
	(28, 'report', 'robot', 'desmond', 'ZuÅ¼ycie ÅºrÃ³deÅ‚ zasobÃ³w', 'Z powodu niedbalstwa, czÄ™Å›Ä‡ naszych ÅºrÃ³deÅ‚ zostaÅ‚a utracona. MoÅ¼liwe, Å¼e komuÅ› udaÅ‚o siÄ™ je wykraÅ›Ä‡!<br /><br />Metal: <b>7.50</b><br />Uran: <b>12.50</b><br />', 1, '1653730766');
/*!40000 ALTER TABLE `galaxy_messages` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_news
CREATE TABLE IF NOT EXISTS `galaxy_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` varchar(14) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` varchar(6) COLLATE latin1_general_ci NOT NULL,
  `from` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `locale` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `message` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='news';

-- Dumping data for table stellar.galaxy_news: 5 rows
/*!40000 ALTER TABLE `galaxy_news` DISABLE KEYS */;
INSERT INTO `galaxy_news` (`id`, `timestamp`, `type`, `from`, `locale`, `message`) VALUES
	(1, '20050116024946', '', 'zoltarx', 'en', 'Testing <b>news</b> section... seems to me workin\' ;-)<p />This would probably be the best global messaging system related to the game itself.<p />Finnaly tried to bring it out as an <i>OpenSource</i> project. And of course FREE, think it\'s due to all game users which support this project with lots of good ideas (preferably)...<p />Students\' time is coming soon (egzams) so it will be a little break in working around code... Be patient.<p />Game status changed to development stage. As long as it will be <i>unstable</i> you may be affected by some bugs - HUMAN ERRORS, eh...<p /><b>Grtx</b> to all mentioned in <a href="CHANGELOG">CHANGELOG</a>.'),
	(2, '20050116025616', '', 'zoltarx', 'pl', 'Tost newsa zoltarowego :D'),
	(30, '1182697288', 'global', 'desmond', 'pl', 'test'),
	(31, '1182697300', '', 'desmond', 'pl', 'hdfg'),
	(29, '1182695789', '', 'desmond', 'pl', 'test');
/*!40000 ALTER TABLE `galaxy_news` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_places
CREATE TABLE IF NOT EXISTS `galaxy_places` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `position` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `type` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `parameters` varchar(240) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `extra` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `level` int(11) NOT NULL DEFAULT '0',
  `reputation` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=77 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy_places';

-- Dumping data for table stellar.galaxy_places: 65 rows
/*!40000 ALTER TABLE `galaxy_places` DISABLE KEYS */;
INSERT INTO `galaxy_places` (`id`, `position`, `type`, `parameters`, `extra`, `level`, `reputation`) VALUES
	(1, 'ben', 'mercenary', '1.2', '', 0, 0),
	(2, 'ring', 'mercenary', '0.8', '', 0, 0),
	(3, 'mouse', 'mercenary', '2.5', '', 0, 0),
	(5, 'angus', 'healer', '1', '', 0, 0),
	(6, 'angus', 'arena', '', '', 0, 0),
	(8, 'ring', 'bank', '1000000', '', 7, 0),
	(9, 'ben', 'bank', '500000', '', 5, 0),
	(10, 'ben', 'healer', '1', '', 0, 0),
	(11, 'ben', 'arena', '', '', 0, 0),
	(45, 'darkstar', 'clanhall', '5', '', 0, 0),
	(14, 'phantasmagoria', 'arena', '', '', 0, 0),
	(48, 'phantasmagoria', 'mines', '4', '', 0, 0),
	(43, 'mouse', 'clanhall', '2', '', 0, 0),
	(17, 'mouse', 'arena', '', '', 0, 0),
	(18, 'mouse', 'mines', '2', '', 0, 0),
	(19, 'ring', 'arena', '', '', 0, 0),
	(20, 'mulahay', 'teleport', 'amoeba', '10000', 0, 0),
	(21, 'mulahay', 'tracker', '500', '', 0, 0),
	(23, 'harmony', 'teleport', 'darkstar', '15000', 0, 0),
	(24, 'phantasmagoria', 'teleport', 'nemesis', '12000', 0, 0),
	(25, 'earth2', 'teleport', 'ring', '13000', 0, 0),
	(26, 'earth2', 'tracker', '100', '', 0, 0),
	(29, 'angus', 'gambler', '15', '', 0, 0),
	(27, 'amoeba', 'abandoned', '1', '', 0, 0),
	(30, 'earth2', 'gambler', '50', '', 0, 0),
	(31, 'mouse', 'gambler', '30', '', 0, 0),
	(32, 'phantasmagoria', 'abandoned', '10', '', 0, 0),
	(33, 'ben', 'mines', '1', 'uran', 0, 0),
	(34, 'amoeba', 'mines', '3', '', 0, 0),
	(35, 'amoeba', 'arena', '', '', 0, 0),
	(36, 'harmony', 'tracker', '700', '', 0, 0),
	(37, 'mouse', 'arena', '', '', 0, 0),
	(39, 'mouse', 'healer', '1', '', 0, 0),
	(40, 'mulahay', 'academy', '1000', '', 0, 0),
	(41, 'mulahay', 'mercenary', '1', '', 0, 0),
	(42, 'earth2', 'clanhall', '1', '', 0, 0),
	(44, 'harmony', 'bank', '10000000', '', 15, 0),
	(46, 'phantasmagoria', 'healer', '1', '', 0, 0),
	(47, 'phantasmagoria', 'gambler', '100', '', 0, 0),
	(49, 'ariel', 'itemshop', 'knife,lightarmor,belt,xtd,pins,lance,helmet,paralyzer', '', 0, 0),
	(50, 'enea', 'itemshop', 'energyarmor,lightninggun,plasmagun,powerbelt,belt,powerhelmet,blaster,stungun,riffle', '15', 0, 0),
	(51, 'sula', 'itemshop', 'a3,gin,scanner,ultraspade', '8', 0, 0),
	(52, 'nemesis', 'arena', '', '', 0, 0),
	(53, 'eye', 'mercenary', '10', '', 0, 0),
	(54, 'erathia', 'gambler', '25', '', 0, 0),
	(55, 'erathia', 'bank', '300000', '', 3, 0),
	(56, 'phantomia', 'bank', '5000000', '', 12, 0),
	(57, 'phantomia', 'healer', '75', '', 0, 0),
	(58, 'phantomia', 'arena', '', '', 0, 0),
	(59, 'gemini', 'thoria', '1', 'uran', 0, 0),
	(60, 'quarell', 'thoria', '2', 'crystals', 0, 0),
	(61, 'darkstar', 'teleport', 'prophetie', '50000000', 0, 0),
	(62, 'prophetie', 'arena', '', '', 0, 0),
	(69, 'yareach', 'itemshop', 'crystalhelmet,crystalarmor,diamondearrings,suonn', '15', 0, 0),
	(64, 'prophetie', 'mines', '20', '', 0, 0),
	(65, 'yareach', 'teleport', 'ben', '15000000', 0, 0),
	(66, 'prophetie', 'healer', '200', '', 0, 0),
	(68, 'prophetie', 'gambler', '1000', '', 0, 0),
	(70, 'eye', 'forcesource', '1', '2', 0, 0),
	(71, 'dreamer', 'forcesource', '10', '5', 0, 0),
	(72, 'ring', 'itemshop', 'spade,creditcard', '1', 0, 0),
	(73, 'phantasmagoria', 'gemshop', 'yellowgem,orangegem,greengem,redgem', '5', 0, 0),
	(74, 'nemesis', 'gemshop', 'redgem,whitegem', '5', 0, 0),
	(75, 'ben', 'starport', 'hawk,nemesis,bee,cage,cage|llasercannon,lasercannon,xengine,ionengine,titaniumplates', '5', 0, 0),
	(76, 'ben', 'clanhall', '2', '', 0, 0);
/*!40000 ALTER TABLE `galaxy_places` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_productions
CREATE TABLE IF NOT EXISTS `galaxy_productions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `begin` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `amount` mediumint(9) NOT NULL DEFAULT '0',
  `score` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_productions: 0 rows
/*!40000 ALTER TABLE `galaxy_productions` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_productions` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_researches
CREATE TABLE IF NOT EXISTS `galaxy_researches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `begin` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `score` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_researches: 0 rows
/*!40000 ALTER TABLE `galaxy_researches` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_researches` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_ships
CREATE TABLE IF NOT EXISTS `galaxy_ships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `name` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `type` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `damaged` int(12) NOT NULL,
  `stardate` int(11) NOT NULL,
  `won` varchar(12) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `lost` varchar(12) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `takencrew` text COLLATE latin1_general_ci NOT NULL,
  `weaponry` text COLLATE latin1_general_ci NOT NULL,
  `components` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumping data for table stellar.galaxy_ships: 1 rows
/*!40000 ALTER TABLE `galaxy_ships` DISABLE KEYS */;
INSERT INTO `galaxy_ships` (`id`, `owner`, `name`, `type`, `damaged`, `stardate`, `won`, `lost`, `takencrew`, `weaponry`, `components`) VALUES
	(1, 'desmond', 'hawk', 'nemesis', 0, 0, '0', '0', 'soldiers,10', '', '');
/*!40000 ALTER TABLE `galaxy_ships` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_space
CREATE TABLE IF NOT EXISTS `galaxy_space` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `type` enum('planet','asteroid','meteor') COLLATE latin1_general_ci NOT NULL DEFAULT 'planet',
  `class` enum('small','medium','big','huge','giant') COLLATE latin1_general_ci NOT NULL DEFAULT 'medium',
  `technology` enum('none','human','tron','ami','cyber','necro','unknown') COLLATE latin1_general_ci NOT NULL DEFAULT 'human',
  `galaxy` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `system` varchar(11) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `x` int(11) NOT NULL DEFAULT '0',
  `y` int(11) NOT NULL DEFAULT '0',
  `z` int(11) NOT NULL DEFAULT '0',
  `explored` float NOT NULL DEFAULT '0',
  `abandoned` int(11) NOT NULL DEFAULT '0',
  `wind` tinyint(4) NOT NULL DEFAULT '15',
  `life` int(11) NOT NULL DEFAULT '30',
  `terrain` int(11) NOT NULL DEFAULT '50',
  `gravity` float NOT NULL DEFAULT '2.5',
  `moons` int(11) NOT NULL DEFAULT '0',
  `illumination` int(11) NOT NULL DEFAULT '15',
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_space: 33 rows
/*!40000 ALTER TABLE `galaxy_space` DISABLE KEYS */;
INSERT INTO `galaxy_space` (`id`, `name`, `type`, `class`, `technology`, `galaxy`, `system`, `x`, `y`, `z`, `explored`, `abandoned`, `wind`, `life`, `terrain`, `gravity`, `moons`, `illumination`) VALUES
	(1, 'angus', 'planet', 'big', 'human', 'home', 'M-14', 3, 1, 3, 12.735, 2606, 13, 53, 21, 5, 1, 43),
	(2, 'ring', 'planet', 'big', 'human', 'home', '', -3, -5, -1, 17.88, 926, 17, 34, 41, 3, 11, 35),
	(3, 'ben', 'planet', 'medium', 'human', 'home', 'M-14', 0, 2, 3, 1.458, 1388, 16, 37, 31, 2, 2, 47),
	(4, 'mouse', 'planet', 'small', 'human', 'onion', 'Bree-37', -1, 0, 0, 35.016, 568, 12, 63, 26, 3, 2, 61),
	(5, 'erathia', 'planet', 'big', 'ami', 'maya', '', -7, 4, 0, 0, 0, 1, 30, 50, 2.5, 0, 15),
	(6, 'darkstar', 'planet', 'medium', 'tron', 'tron', '', 0, -1, 2, 1.014, 107, 40, 30, 50, 2.5, 0, 15),
	(7, 'harmony', 'planet', 'big', 'ami', 'onion', '', -4, 3, 7, 0, 0, 3, 11, 13, 7, 4, 76),
	(8, 'hybrid', 'planet', 'huge', 'ami', 'maya', 'Ameno XIV', 3, 12, 8, 0, 0, 3, 30, 50, 2.5, 0, 15),
	(9, 'phantasmagoria', 'planet', 'giant', 'tron', 'tron', '', 4, 2, -1, 0.45, 86, 25, 30, 50, 2.5, 0, 15),
	(10, 'dreamer', 'planet', 'small', 'ami', 'maya', '', -5, 4, -3, 0, 1, 2, 30, 50, 2.5, 0, 15),
	(11, 'eye', 'planet', 'huge', 'ami', 'plexi', '', -2, -1, 7, 0, 1, 1, 30, 50, 2.5, 0, 15),
	(12, 'galeon', 'planet', 'huge', 'tron', 'plexi', '', -4, -20, 17, 0, 83, 35, 30, 50, 2.5, 0, 15),
	(13, 'mulahay', 'planet', 'medium', 'human', 'home', '', 20, 15, 10, 40.938, 761, 9, 17, 54, 2.5, 3, 30),
	(14, 'amoeba', 'planet', 'huge', 'human', 'onion', '', 5, -7, 3, 48.762, 816, 21, 71, 63, 5, 0, 23),
	(15, 'earth2', 'planet', 'medium', 'human', 'wolf', '', 0, 0, 0, 3.708, 850, 17, 70, 40, 2, 2, 40),
	(16, 'nemesis', 'planet', 'giant', 'tron', 'wolf', '', 66, 66, 66, 0, 99, 70, 30, 50, 2.5, 0, 15),
	(17, 'ariel', 'asteroid', 'medium', 'none', 'onion', 'Bree-37', -2, 0, -1, 0, 0, 0, 0, 0, 1, 0, 15),
	(18, 'gemini', 'meteor', 'big', 'none', 'onion', '', 4, 5, -3, 0, 7, 0, 0, 0, 10, 0, 0),
	(19, 'sula', 'asteroid', 'medium', 'none', 'maya', 'Ameno XIV', 4, 10, 7, 0, 0, 0, 0, 0, 1, 0, 15),
	(20, 'enea', 'asteroid', 'medium', 'none', 'tron', '42', 22, 5, -7, 0, 0, 0, 0, 0, 5, 0, 15),
	(21, 'phantomia', 'planet', 'medium', 'cyber', 'onion', 'Zoob-XVII', -7, -8, -10, 5.064, 5, 79, 42, 59, 20, 7, 35),
	(22, 'prophetie', 'planet', 'giant', 'necro', 'underverse', '', 0, 0, 0, 0.1512, 6, 0, -100, 100, 15, 50, 15),
	(23, 'quarell', 'meteor', 'small', 'none', 'plexi', '', -3, -10, 11, 0, 0, 0, 0, 0, 5, 0, 15),
	(24, 'yareach', 'planet', 'medium', 'necro', 'underverse', '', 446, 336, 446, 8.82, 2, 33, 0, 77, 50, 6, 16),
	(25, 'antar', 'asteroid', '', 'none', 'wolf', 'Cularian Li', -49, 30, 27, 0, 0, 0, 0, 0, 10, 0, 15),
	(26, 'tatooine', 'planet', 'huge', 'human', 'wolf', 'Twin Sector', -40, 43, 32, 10.128, 119, 63, 46, 60, 14, 2, 45),
	(27, 'yavin', 'planet', 'small', 'human', 'wolf', 'Ando Space', -53, 7, -4, 47.832, 43, 17, 53, 41, 2.5, 0, 55),
	(28, 'endor', 'planet', 'giant', 'human', 'wolf', 'Ando Space', -51, -1, 3, 8.21628, 64, 15, 61, 77, 8.5, 9, 53),
	(29, 'dagobah', 'planet', 'medium', 'human', 'wolf', '', -71, 42, 15, 35.388, 64, 33, 50, 67, 29, 1, 21),
	(30, 'velmor', 'asteroid', '', 'none', 'wolf', 'Cularian Li', -44, 33, 25, 0, 0, 0, 0, 0, 10, 0, 15),
	(31, 'ruan', 'asteroid', '', 'none', 'wolf', 'Cularian Li', -47, 31, 32, 0, 0, 0, 0, 0, 10, 0, 15),
	(32, 'crematoria', 'planet', 'big', 'none', 'tron', '', -15, -24, -31, 0, 0, 5, 0, 100, 10, 0, 100),
	(33, 'coruscant', 'planet', 'big', 'human', 'wolf', 'Twin Sector', -43, 41, 30, 26.0455, 75, 9, 19, 41, 5, 0, 17);
/*!40000 ALTER TABLE `galaxy_space` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_stats
CREATE TABLE IF NOT EXISTS `galaxy_stats` (
  `key` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `value` varchar(224) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumping data for table stellar.galaxy_stats: 0 rows
/*!40000 ALTER TABLE `galaxy_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_stats` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_tales
CREATE TABLE IF NOT EXISTS `galaxy_tales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `from` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `locale` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `level` int(11) NOT NULL DEFAULT '0',
  `subject` varchar(80) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `message` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_tales: 2 rows
/*!40000 ALTER TABLE `galaxy_tales` DISABLE KEYS */;
INSERT INTO `galaxy_tales` (`id`, `timestamp`, `from`, `locale`, `level`, `subject`, `message`) VALUES
	(1, '2005-01-17 15:59:31', 'zoltarx', 'en', 10, 'Maya War part I', 'It is well known fact that one of the older conflicts between Ami and Tron has rather small influence on humanoid races. If not metioned that it helped a little Human technology to grown again of course. Maya War was the first real sign that Tron armies are not so significant. One of the biggest galaxies Maya became unreachable for them.<p>During that times Tron discovered very dangerous <i>starship</i> made in the Ami technology. First stolen <a href="description.php?type=unit&name=bee">Bee</a> units shown Human technology has to be modified.<p>Maya War was the first open army conflict which Tron lost almost all its power. Unfortunately most of the information about that conflict is incomplete. The duration of Maya War is said to be about 2k star-years.'),
	(2, '2005-01-17 15:59:31', 'zoltarx', 'pl', 10, 'Maya War cz??? I', 'Jest bardzo dobrze znanym fakt A1e jeden z najsatrszych konfliktA3w pomiÄ?dzy Ami i Tronem miaA? niewielki wpA?yw na rasy humanoidalne. JeA?li oczywiA?cie nie wspomnieÄ? o tym, A1e pomogA?o to nieco powstaÄ? na nowo technologii ludzi. Wojna w galaktyce Maya staA?a siÄ? pierwszym prawdziwym znakiem, A1e armie Tronu nie sÄ? aA1 tak znaczÄ?ce. Jedna z najwiÄ?kszych galaktek staA?a siÄ? dla nich nieosiÄ?galna.<p>Podczas tamtych czasA3w Tron odkryA? strasznÄ? <i>jednostkÄ?</i> zbudowanÄ? w technologii Ami. Pierwsze ukradzione jednostki <a href="description.php?type=unit&name=bee">Bee</a> ukazaA?y potrzebÄ? modyfikacji technologii ludzkiej.<p>Maya War byA?a pierwszym otwartym zbrojnym konfliktem podczas ktA3rego Tron straciA? prawie caA?Ä? swÄ? moc. Niestety wiÄ?kszoA?Ä? informacji na temat tego konfliktu jest niekompletna. Czas trwania wojny okreA?la siÄ? na ok. 2k lat gwiezdnych.');
/*!40000 ALTER TABLE `galaxy_tales` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_tips
CREATE TABLE IF NOT EXISTS `galaxy_tips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locale` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `tip` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- Dumping data for table stellar.galaxy_tips: 30 rows
/*!40000 ALTER TABLE `galaxy_tips` DISABLE KEYS */;
INSERT INTO `galaxy_tips` (`id`, `locale`, `tip`) VALUES
	(1, 'en', 'If you have colony based on human technology you need people to work. You can hire them at the Mercenary places located on some planets but remember that the hire cost depends on your reputation.'),
	(2, 'pl', 'Je¶li posiadasz kolonie w technologii ludzi potrzebujesz ich do pracy. Mo?esz ich naj±a w obozach najemników na niektórych planetach, pamietaj jednak, ?e koszt najecia zale?y od twojej reputacji.'),
	(3, 'en', 'Your colony needs energy. It is good first to build some Wind generators or Solar batteries, these buldings give you some energy depend on planet parameters where your colony is located.'),
	(4, 'pl', 'Twoja kolonia potrzebuje pr±du (energii). Dobrze jest najpierw wybudowaa nieco elektrowni wiatrowych lub baterii s3onecznych, daj± one energie w zale?no¶ci od wspó3czynników planety na której znajduje sie twoja kolonia.'),
	(5, 'en', 'The most important thing in creating your colony is to find some sources: uran, metal, etc. To find them you need to explore your planet or space.'),
	(6, 'pl', 'Najwa?niejsz± rzecz± we wczesnej rozbudowie kolonii jest znalezienie 1róde3: metalu, uranu, itp. By je odnale1a musisz wysy3aa wyprawy.'),
	(7, 'en', 'Instead of building you need to produce some units. There are few kinds of them, i.e. robots that work for you or fighters that fights :-) You need to build a factory to produce anything. The more factories you have the more productions you can have at the same time.'),
	(8, 'pl', 'Oprócz budynków potrzebujesz jednostek. Jest ich kilka rodzajów, np. roboty, które pracuj± dla ciebie lub statki wojenne, których potrzebujesz do wojny. Musisz wybudowaa fabryke by cokolwiek produkowaa. Im wiecej fabryk masz, tym wiecej produkcji mo?esz rozpocz±a w jednym czasie.'),
	(9, 'en', 'Building structures goes faster if your colony has large amount of robots. To produce robots faster you have to build more factories.'),
	(10, 'pl', 'Budowy konstrukcji trwaj± krócej je¶li twoja kolonia jest wyposa?ona w du?± ilo¶a robotów. Produkcja robotów z kolei trwa krócej je¶lli ma sie du?o fabryk.'),
	(11, 'en', 'To find more sources you need to explore your planet or space. Other way to gain some sources for your colony is to work in mines or thoria.'),
	(12, 'pl', 'By znale1a 1ród3a które nadaj± sie do eksploatacji musisz wysy3aa wyprawy. Inny sposób to praca w kopalniach lub thorii.'),
	(13, 'en', 'Your colony and your hero are two different thing. You can travel around universe and still have control on your colony which is located on some planet that you have chosen.'),
	(14, 'pl', 'Twoja kolonia i twój bohater to dwie ró?ne rzeczy. Mo?esz podró?owaa po wszech¶wiecie i wci±? kontrolowaa rozwój kolonii, która znajduje sie na planecie która zosta3a wybrana podczas jej tworzenia.'),
	(15, 'en', 'If you have any questions you can use chat, normally it is full of some strange sayings but if you ask most likely someone will answer.'),
	(16, 'pl', 'Je¶li masz jakie¶ pytania, zawsze mo?esz u?ya czata. Jest on zazwyczaj wype3niony dziwnymi wypowiedziami, jednak je¶li zadasz pytanie, w wiekszo¶ci wypadków, kto¶ na nie odpowie.'),
	(17, 'en', 'Forum is the first place you should visit to begin playing in our game.'),
	(18, 'pl', 'Forum jest pierwszym miejscem które powiniene¶ (powinna¶) odwiedzia przed rozpoczeciem gry.'),
	(19, 'en', 'Your score is a rating that gives you higher position in high scores list but you must remember that the more score you have the stronger players can attack your colony!'),
	(20, 'pl', 'Twoje punkty daj± wy?sz± pozycje w wynikach, jednak musisz pamietaa, ?e im wiecej punktów posiadasz, tym silniejsi gracze bed± mogli atakowaa tw± kolonie.'),
	(21, 'en', 'Sending scientists to exploration increases possibility to find valuable sources.'),
	(22, 'pl', 'Wys3anie naukowców na wyprawy zwieksza mo?liwo¶a znalezienia cennych 1róde3.'),
	(23, 'en', 'If you don\'t care of food for your people they may die and your reputation will go down.'),
	(24, 'pl', 'Je¶li nie zadbasz o dostepne jedzenie dla ludzi w kolonii, mog± oni umrzea z g3odu, tym samym spadnie twoja reputacja.'),
	(25, 'en', 'Always check your colony bilances. It is very valuable information.'),
	(26, 'pl', 'Zawsze sprawdzaj bilans przyrostu/zu?ycia surowców swojej kolonii. Jest to naprawde cenna informacja.'),
	(27, 'en', 'Your hero attributes can be checked in whois section where you can go by clicking on your login.'),
	(28, 'pl', 'Wspó3czynniki swojej postaci mo?esz zobaczya w oknie informacji o graczu do którego mo?esz przej¶a klikaj±c po prostu na swój login.'),
	(29, 'en', 'Your hero can gain some new abilities during game. You won\'t see them unless you gain at least one point to them. If you already have you will have ability to distribute skillpoints to them.'),
	(30, 'pl', 'Twoja postaa mo?e zyskaa nowe zdolno¶ci/atrybuty, nie zobaczysz ich jednak dopóki nie zdobedziesz przynajmniej jednego punktu w danej zdolno¶ci. Kiedy ju? postaa uzyska now± zdolno¶a, bedzie mo?na przeznaczya na ni± punkty zdolno¶ci SP.');
/*!40000 ALTER TABLE `galaxy_tips` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_transfers
CREATE TABLE IF NOT EXISTS `galaxy_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `to` varchar(32) COLLATE latin1_general_ci NOT NULL,
  `begin` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  `metal` int(11) NOT NULL DEFAULT '0',
  `uran` int(11) NOT NULL DEFAULT '0',
  `food` int(11) NOT NULL DEFAULT '0',
  `crystals` int(11) NOT NULL DEFAULT '0',
  `colonists` int(11) NOT NULL DEFAULT '0',
  `scientists` int(11) NOT NULL DEFAULT '0',
  `soldiers` int(11) NOT NULL DEFAULT '0',
  `bx1` int(11) NOT NULL DEFAULT '0',
  `bx2` int(11) NOT NULL DEFAULT '0',
  `bx5` int(11) NOT NULL DEFAULT '0',
  `bx10` int(11) NOT NULL DEFAULT '0',
  `hawk` int(11) NOT NULL DEFAULT '0',
  `crusader` int(11) NOT NULL DEFAULT '0',
  `warrior` int(11) NOT NULL DEFAULT '0',
  `dragon` int(11) NOT NULL DEFAULT '0',
  `nemesis` int(11) NOT NULL DEFAULT '0',
  `scavenger` int(11) NOT NULL DEFAULT '0',
  `carrier` int(11) NOT NULL DEFAULT '0',
  `vessel` int(11) NOT NULL DEFAULT '0',
  `detector` int(11) NOT NULL DEFAULT '0',
  `bee` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_transfers: 0 rows
/*!40000 ALTER TABLE `galaxy_transfers` DISABLE KEYS */;
/*!40000 ALTER TABLE `galaxy_transfers` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_universe
CREATE TABLE IF NOT EXISTS `galaxy_universe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `x` int(11) NOT NULL DEFAULT '0',
  `y` int(11) NOT NULL DEFAULT '0',
  `z` int(11) NOT NULL DEFAULT '0',
  `type` enum('galaxy','anomaly','blackhole') COLLATE latin1_general_ci NOT NULL DEFAULT 'galaxy',
  `discovered` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `by` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `age` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='galaxy';

-- Dumping data for table stellar.galaxy_universe: 8 rows
/*!40000 ALTER TABLE `galaxy_universe` DISABLE KEYS */;
INSERT INTO `galaxy_universe` (`id`, `name`, `x`, `y`, `z`, `type`, `discovered`, `by`, `age`) VALUES
	(1, 'home', 0, 0, 0, 'galaxy', '', '', '233'),
	(2, 'onion', 1, 2, 3, 'galaxy', '', '', '487'),
	(3, 'tron', -5, -5, -30, 'galaxy', '', '', ''),
	(4, 'wolf', 2, -1, -1, 'galaxy', '', '', ''),
	(5, 'maya', -7, 2, 5, 'galaxy', '', '', ''),
	(6, 'plexi', 3, -2, -1, 'galaxy', '', '', ''),
	(8, 'underverse', -10101, -10101, -333000, 'anomaly', '', '', ''),
	(9, 'axis', -200, 5000, 50, 'blackhole', '', '', '');
/*!40000 ALTER TABLE `galaxy_universe` ENABLE KEYS */;

-- Dumping structure for table stellar.galaxy_users
CREATE TABLE IF NOT EXISTS `galaxy_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` tinyint(2) NOT NULL DEFAULT '0',
  `online` varchar(14) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `login` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `password` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `seed` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `usergroup` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `clanrank` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `options` text COLLATE latin1_general_ci NOT NULL,
  `race` varchar(16) COLLATE latin1_general_ci NOT NULL,
  `clan` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `gg` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `www` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `language` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `style` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `regid` varchar(12) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `refid` int(11) NOT NULL,
  `refs` int(11) NOT NULL,
  `registered` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `seen` varchar(14) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `vacation` varchar(14) COLLATE latin1_general_ci NOT NULL,
  `locked` varchar(14) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `banned` varchar(14) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `bancount` int(11) NOT NULL DEFAULT '0',
  `who` varchar(35) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `reason` text COLLATE latin1_general_ci NOT NULL,
  `regip` varchar(64) COLLATE latin1_general_ci NOT NULL,
  `ip` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `lastip` varchar(64) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `credits` bigint(20) NOT NULL DEFAULT '100000',
  `bank` bigint(20) NOT NULL DEFAULT '0',
  `score` int(11) NOT NULL DEFAULT '0',
  `reputation` float NOT NULL DEFAULT '0',
  `exp` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '1',
  `action` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `hidden_location` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `planet` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT 'mulahay',
  `destination` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `time` int(11) NOT NULL DEFAULT '0',
  `distance` float NOT NULL DEFAULT '0',
  `voyaged` float NOT NULL DEFAULT '0',
  `hp` float NOT NULL DEFAULT '10',
  `hpmin` mediumint(9) NOT NULL DEFAULT '25',
  `hpmax` float NOT NULL DEFAULT '10',
  `hpgain` float NOT NULL DEFAULT '0.2',
  `hpmodifier` varchar(8) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `mp` float NOT NULL DEFAULT '10',
  `mpmax` float NOT NULL DEFAULT '10',
  `mpgain` float NOT NULL DEFAULT '0.1',
  `mpmodifier` varchar(8) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `thicks` mediumint(9) NOT NULL DEFAULT '0',
  `ship` varchar(16) COLLATE latin1_general_ci NOT NULL DEFAULT 'hawk',
  `strengthmodifier` varchar(8) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `agilitymodifier` float NOT NULL DEFAULT '0',
  `skills` text COLLATE latin1_general_ci NOT NULL,
  `modifiers` text COLLATE latin1_general_ci NOT NULL,
  `killed` mediumint(9) NOT NULL DEFAULT '0',
  `killedby` mediumint(9) NOT NULL DEFAULT '0',
  `lastkilled` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `lastkilledby` varchar(32) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `sp` mediumint(9) NOT NULL DEFAULT '2',
  `avatar` varchar(128) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `login` (`login`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci COMMENT='system';

-- Dumping data for table stellar.galaxy_users: 10 rows
/*!40000 ALTER TABLE `galaxy_users` DISABLE KEYS */;
INSERT INTO `galaxy_users` (`id`, `active`, `online`, `login`, `password`, `seed`, `usergroup`, `clanrank`, `options`, `race`, `clan`, `email`, `gg`, `www`, `language`, `style`, `regid`, `refid`, `refs`, `registered`, `seen`, `vacation`, `locked`, `banned`, `bancount`, `who`, `reason`, `regip`, `ip`, `lastip`, `credits`, `bank`, `score`, `reputation`, `exp`, `level`, `action`, `hidden_location`, `planet`, `destination`, `time`, `distance`, `voyaged`, `hp`, `hpmin`, `hpmax`, `hpgain`, `hpmodifier`, `mp`, `mpmax`, `mpgain`, `mpmodifier`, `thicks`, `ship`, `strengthmodifier`, `agilitymodifier`, `skills`, `modifiers`, `killed`, `killedby`, `lastkilled`, `lastkilledby`, `sp`, `avatar`) VALUES
	(2, 2, '1653744062', 'desmond', '708111aa93d5d4d2f04ae9dee4ab5cf5', '7c4e9876441eb288', 'admin', '', 'soundsoff,1', 'human', 'Kademlia', 'desmond', '2634190', 'tostownia', 'pl', '', '', 0, 0, '2007-04-10', '1653742985', '', '', '', 6, 'Autocensor', 'Swearing - 55 minutes', '', '127.0.0.1', '', 59921768107, 0, 20, -3.78, '1618.45454545', 5, ';;', '', 'ben', '', 0, 0, 0, 104.9, 25, 104.9, 10.84, '', 97.7, 97.7, 10.24, '', 1872184, 'nemesis', '', 0, 'strength,agility,20.68,20.84', '', 1, 0, 'lord_nacro', '', 668, 'http://localhost/galaxy_project/sq/gallery/space/icons/ben.jpg'),
	(3, 1, '20070609200340', 'lord_nacro', 'f3fe66866afa6153235ddf86e9dfc049', '6b0b103af398eceb', '', '', 'antispam,1', 'human', '', 'lord.nacro@gmail.com', '', '', 'pl', '', '', 0, 0, '2007-04-20', '20070609193942', '', '', '', 0, '', '', '', '81.190.71.193', '', 100000, 0, 0, -0.78, '0', 1, '', '', 'ben', '', 0, 0, 0, 10, 25, 10, 0.2, '', 10, 10, 0.1, '', 320710, 'nemesis', '', 0, '', '', 0, 1, '', 'desmond', 2, ''),
	(4, 1, '', 'plit', 'f77a22ca0a8af1c1f6e80358740effec', '', '', '', '', '', 'Kademlia', 'plit@op.pl', '', '', 'pl', '', '', 0, 0, '2007-04-21', '20070421125120', '', '', '', 0, '', '', '', '84.40.221.5', '', 90385, 0, 7, 0, '0', 1, '', '', 'ben', '', 0, 0, 0, 10, 25, 10, 0.2, '', 0.1, 10, 0.23, '', 283547, 'hawk', '', 0, '', '', 0, 0, '', '', 0, ''),
	(5, 1, '20070422170813', 'wandal', '1ab269b18b02be6e252b94e1c694a7be', '462ee18fd652d443', '', '', '', '', 'Kademlia', 'najowka@wp.pl', '', '', 'pl', '', '', 0, 0, '2007-04-22', '20070422170747', '', '20070625111611', '', 1, 'desmond', 'test', '', '88.199.29.7', '', 100000, 0, 0, -0.2, '0', 1, '', '', 'ben', '', 0, 0, 0, 10, 25, 10, 0.2, '', 10, 10, 0.1, '', 283885, 'hawk', '', 0, '', '', 0, 0, '', '', 2, ''),
	(6, 1, '', 'pafawag', 'a45f28ceaa1cfc1ad8ef8c400bbb2eae', '', '', '', '', 'tron', 'Kademlia', 'pafawag@starwars.pl', '3240475', 'www.starwars.pl', 'pl', '', '', 0, 0, '2007-04-24', '1182343704', '', '', '', 2, 'Autocensor', 'Swearing - 35 minutes', '', '83.6.52.168', '83.6.51.128', 94180, 0, 0, -0.1, '39.0196078431', 1, '', '', 'ben', '', 0, 0, 0, 1.09, 25, 10, 0.2, '', 0.75, 10, 0.25, '', 300853, 'hawk', '', 0, '', '', 1, 0, 'unk', '', 0, ''),
	(7, 1, '20070505105621', 'hacker', 'c8837b23ff8aaa8a2dde915473ce0991', '92278b3ee013d4a6', '', '', '', '', 'Kademlia', 'asd@das.pl', '', '', 'pl', '', '', 0, 0, '2007-05-05', '20070505105606', '', '', '', 0, '', '', '', '62.21.86.212', '', 100000, 0, 0, 0, '0', 1, '', '', 'ben', '', 0, 0, 0, 10, 25, 10, 0.2, '', 10, 10, 0.1, '', 287555, 'hawk', '', 0, '', '', 0, 0, '', '', 2, ''),
	(8, 1, '20070609193117', 'unk', 'd3cf8cae2fccf5437f442d8fe7c7a046', '9e358fd427c12071', '', '', '', 'tron', 'Kademlia', 'dawid.unk@gmail.com', '', '', 'pl', '', '', 0, 0, '2007-06-07', '20070609193110', '', '', '', 0, '', '', '', '83.17.152.132', '', 90428, 0, 0, 0, '0', 1, '', '', 'ben', '', 0, 0, 0, 10, 25, 10, 0.2, '', 10, 10, 0.1, '', 319616, 'hawk', '', 0, '', '', 0, 1, '', 'pafawag', 2, ''),
	(27, 1, '', 'lord_dupek', '538e7aa4a252042346b85d90f4eca14b', '', '', '', '', '', '', 'lord_dupek@op.pl', '', '', 'pl', '', '', 0, 0, '1187190735', '', '', '', '', 0, '', '', '127.0.0.1', '', '', 100000, 0, 0, 0, '0', 1, '', '', 'mulahay', '', 0, 0, 0, 10, 25, 10, 0.2, '', 10, 10, 0.1, '', 0, 'hawk', '', 0, '', '', 0, 0, '', '', 2, ''),
	(26, 1, '', 'lord_nacro33', '831e2ab1640c18aa974725f98e718726', '', '', '', '', '', '', 'plit@op.pl233', '', '', 'pl', '', '127.0.0.1', 0, 0, '1187190353', '', '', '', '', 0, '', '', '', '', '', 100000, 0, 0, 0, '0', 1, '', '', 'mulahay', '', 0, 0, 0, 10, 25, 10, 0.2, '', 10, 10, 0.1, '', 0, 'hawk', '', 0, '', '', 0, 0, '', '', 2, ''),
	(28, 1, '1187482993', 'toster', '1952c779f618c09908e6f799f6d62740', '3db4de28f17417d4', '', '', '', '', 'Kademlia', '', '', '', 'pl', '', '', 0, 0, NULL, '1187481524', '', '', '', 0, '', '', '', '127.0.0.1', '', 100000, 0, 0, 0, '0', 1, '', '', 'mulahay', '', 0, 0, 0, 10, 25, 10, 0.2, '', 10, 10, 0.1, '', 317980, 'hawk', '', 0, '', '', 0, 0, '', '', 2, '');
/*!40000 ALTER TABLE `galaxy_users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
